import { Component } from '@angular/core';

@Component({
    selector: 'students',
    template: '<h2>{{ getTitle() }}</h2>'
})
export class StudentsComponent {
    title = "My List of Students";

    getCurrentDate(): string {
        const today = new Date();
        return today.toLocaleDateString(); // Formats the date
    }

    getTitle(): string {
        return `${this.title} - ${this.getCurrentDate()}`; // Using Template Literal
    }
}
